1.7.10-1.12.2   ServerSelectorX-3.5.4-legacy.jar
1.13.2+         ServerSelectorX-3.5.4.jar
